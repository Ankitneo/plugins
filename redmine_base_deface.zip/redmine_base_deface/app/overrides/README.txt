This directory is only here to ensure the plugin works through unit tests. It is automatically added to Rails.application.paths["app/overrides"]
